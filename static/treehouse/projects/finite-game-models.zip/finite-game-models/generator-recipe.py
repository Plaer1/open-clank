from collections import deque
def generate(seed, repair=False):
    assert isinstance(seed,int) and 0<=seed<16
    state=seed; grid=[]
    for y in range(5):
        row=[]
        for x in range(5):
            state=(5*state+1)%16
            row.append("#" if state<5 else ".")
        grid.append(row)
    if seed%2==0:
        for x in range(5):grid[0][x]="."
        for y in range(5):grid[y][4]="."
    else:grid[3][4]=grid[4][3]="#"
    grid[0][0]="S";grid[4][4]="E"
    if repair:grid[3][4]="."
    seen={(0,0)};todo=deque([(0,0)])
    while todo:
        x,y=todo.popleft()
        for nx,ny in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
            if 0<=nx<5 and 0<=ny<5 and grid[ny][nx]!="#" and (nx,ny) not in seen:
                seen.add((nx,ny));todo.append((nx,ny))
    return ["".join(row) for row in grid],len(seen),(4,4) in seen
def check():
    cases=[
      (0,False,["S....","#....",".#...","##...",".#..E"],18,True),
      (0,True,["S....","#....",".#...","##...",".#..E"],18,True),
      (1,False,["S...#",".....","#..##","#...#","#..#E"],16,False),
      (1,True,["S...#",".....","#..##","#....","#..#E"],18,True),
      (2,False,["S....","#..#.","#....","#....",".#..E"],19,True),
      (2,True,["S....","#..#.","#....","#....",".#..E"],19,True),
      (3,False,["S#...",".#...","..#..","###.#","..##E"],4,False),
      (3,True,["S#...",".#...","..#..","###..","..##E"],4,False)]
    for seed,repair,rows,count,valid in cases:
        assert generate(seed,repair)==(rows,count,valid),(seed,repair,generate(seed,repair))
    print("generator: eight exact grids/counts/validity passed")
if __name__=="__main__":check()
