from math import floor
def model(generated, authority, delay, step, drop=False, extra=None):
    assert 0 <= generated <= 20 and 0 <= delay <= 5
    now = max(max(0, min(20, floor(step))), generated)
    def total(t): return sum((1, 1, -1)[(i-1)%3] for i in range(1,t+1))
    offset = authority - total(generated)
    rows = [{"id": "s0", "tick": 0, "position": 0, "arrival": 0, "status": "received"}]
    accepted = {0: 0}; ids = {"s0"}; ack = 0
    incoming = [{"id": "s"+str(t), "tick": t, "position": total(t)+offset,
                 "arrival": t+delay, "dropped": drop and t%3==0}
                for t in range(1,generated+1)]
    if extra is not None: incoming.append(dict(extra))
    for packet in sorted(incoming, key=lambda p:(p["arrival"],p["tick"])):
        p = dict(packet)
        if p.get("dropped"): p["status"] = "dropped"
        elif p["arrival"] > now: p["status"] = "pending"
        elif p["id"] in ids: p["status"] = "ignored duplicate"
        elif p["tick"] <= ack: p["status"] = "ignored old"
        else:
            p["status"] = "received"; ids.add(p["id"])
            accepted[p["tick"]] = p["position"]; ack = p["tick"]
        rows.append(p)
    predicted = accepted[ack] + total(now) - total(ack)
    render = max(0,now-1)
    times = sorted(accepted)
    if render in accepted:
        mode, shown, reason = "exact", accepted[render], "accepted timestamp"
    elif any(t > render for t in times):
        lo=max(t for t in times if t<render); hi=min(t for t in times if t>render)
        shown=accepted[lo]+(accepted[hi]-accepted[lo])*(render-lo)/(hi-lo)
        mode, reason = "interpolate", "two accepted samples bracket display time"
    else:
        mode, shown = "hold", accepted[times[-1]]
        reason = ("later packets pending" if any(p["status"]=="pending" for p in rows)
                  else "known dropped packet" if any(p["status"]=="dropped" for p in rows)
                  else "no newer accepted sample")
    return {"now":now,"ack":ack,"accepted":accepted,"predicted":predicted,
            "raw":total(now),"correction":predicted-total(now),
            "renderTime":render,"display":shown,"mode":mode,"reason":reason,"rows":rows}
def check():
    x=model(2,1,0,0,True)
    assert x["accepted"]=={0:0,1:0,2:1} and x["ack"]==2
    assert (x["predicted"],x["raw"],x["correction"],x["display"],x["mode"])==(1,2,-1,0,"exact")
    assert not any(p["status"]=="dropped" for p in x["rows"])
    x=model(2,1,2,0,True)
    assert x["accepted"]=={0:0} and (x["ack"],x["predicted"],x["mode"],x["display"])==(0,2,"hold",0)
    assert x["reason"]=="later packets pending"
    x=model(3,1,0,4,True)
    assert x["accepted"]=={0:0,1:1,2:2}
    assert (x["ack"],x["predicted"],x["raw"],x["correction"],x["display"])==(2,2,2,0,2)
    assert x["reason"]=="known dropped packet"
    x=model(4,2,0,4,True)
    assert x["mode"]=="interpolate" and x["display"]==2
    for extra in [{"id":"s2","tick":2,"position":99,"arrival":4},
                  {"id":"old0","tick":0,"position":99,"arrival":4}]:
        x=model(3,1,0,4,True,extra)
        assert x["ack"]==2 and x["predicted"]==2 and x["rows"][-1]["status"].startswith("ignored")
    print("network: exact, pending, dropped, interpolation, duplicate, old passed")
if __name__=="__main__": check()
