# Tiny native TreeHouse course

This exact package was returned by the actual current native course exporter after an ordinary author command set the original course description to first-party AGPL-3.0-only. The actual importer accepted this package and allocated a new private course identity. It contains two lessons about blue draft versus green saved/reopened notes, reciprocal internal topic anchors, and one response assignment.

Use your permitted private-course Import flow, inspect the resulting private course outline and open both lesson bodies. Expected identities are new, not the original source course IDs. Check internal navigation in your own current UI; this source artifact is not a claim that every client version's imported-link controls work. Body rendering and identity remapping are separate observations.

There are no account profiles, responses, completion records, grants or private media in this package. Importing does not grant a role, preserve somebody else's progress or complete an assignment. Keep the source package and your own actual import/readback result. Original toy content: AGPL-3.0-only; full license included.
