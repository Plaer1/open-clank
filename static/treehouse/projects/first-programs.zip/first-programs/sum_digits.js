function add(a, b) {
  return a + b;
}

function solve(args) {
  if (args.length !== 2) return null;
  for (const text of args) {
    if (text.length !== 1 || !/^[0-9]$/.test(text)) return null;
  }
  return add(Number(args[0]), Number(args[1]));
}

function run(args) {
  const result = solve(args);
  console.log(result === null ? "error: expected two digits 0..9" : `sum=${result}`);
  return result === null ? 2 : 0;
}

function tests() {
  const cases = [[["2", "3"], 5], [["0", "9"], 9],
                 [["pear", "3"], null], [[], null]];
  for (const [input, expected] of cases) {
    if (solve(input) !== expected) {
      console.log("test failure");
      return 1;
    }
  }
  console.log("tests=4 passed");
  return 0;
}
