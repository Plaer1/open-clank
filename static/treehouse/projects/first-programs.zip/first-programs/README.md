# first-programs

Complete original Python/browser-JavaScript/Java tiny and strict-digit programs. Expected tiny output 5; predictions are not observed runs. No server, remote script or provider.

Status: source-only. Extract into a new owned directory. Source/examples do not imply an external tool ran. No automatic app-origin execution; run locally only when you choose the relevant practical work. Keep source/version/evidence and report failed or unavailable tools as pending.
