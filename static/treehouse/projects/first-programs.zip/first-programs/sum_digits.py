import sys


def add(a, b):
    return a + b


def solve(args):
    if len(args) != 2:
        return None
    for text in args:
        if len(text) != 1 or not ("0" <= text <= "9"):
            return None
    return add(int(args[0]), int(args[1]))


if sys.argv[1:] == ["--test"]:
    cases = [(["2", "3"], 5), (["0", "9"], 9),
             (["pear", "3"], None), ([], None)]
    for args, expected in cases:
        if solve(args) != expected:
            print("test failure")
            sys.exit(1)
    print("tests=4 passed")
else:
    result = solve(sys.argv[1:])
    if result is None:
        print("error: expected two digits 0..9")
        sys.exit(2)
    print(f"sum={result}")
