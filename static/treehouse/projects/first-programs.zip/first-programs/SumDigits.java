public class SumDigits {
    static int add(int a, int b) {
        return a + b;
    }

    static Integer solve(String[] args) {
        if (args.length != 2) return null;
        for (String text : args) {
            if (text.length() != 1 || text.charAt(0) < '0' || text.charAt(0) > '9') {
                return null;
            }
        }
        return add(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
    }

    public static void main(String[] args) {
        if (args.length == 1 && args[0].equals("--test")) {
            String[][] inputs = {{"2", "3"}, {"0", "9"}, {"pear", "3"}, {}};
            Integer[] expected = {5, 9, null, null};
            for (int i = 0; i < inputs.length; i++) {
                Integer actual = solve(inputs[i]);
                if (actual == null ? expected[i] != null : !actual.equals(expected[i])) {
                    System.out.println("test failure");
                    System.exit(1);
                }
            }
            System.out.println("tests=4 passed");
            return;
        }
        Integer result = solve(args);
        if (result == null) {
            System.out.println("error: expected two digits 0..9");
            System.exit(2);
        }
        System.out.println("sum=" + result);
    }
}
