extends Node2D
signal collected
var player := Vector2(80, 180)
var targets := [Vector2(260, 180), Vector2(460, 100), Vector2(460, 280)]
var score := 0
var running := false

func _ready():
    collected.connect(_on_collected)
    $Restart.pressed.connect(reset_round)
    $RoundTimer.timeout.connect(_on_timeout)
    reset_round()

func reset_round():
    player = Vector2(80, 180)
    score = 0
    running = true
    $Status.text = "0 / 3 — arrows move; R restarts"
    $RoundTimer.start(20.0)
    queue_redraw()

func _physics_process(delta):
    if Input.is_action_just_pressed("restart"):
        reset_round()
    if running:
        player += Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down") * 180.0 * delta
        player.x = clampf(player.x, 12.0, 628.0)
        player.y = clampf(player.y, 60.0, 348.0)
        if player.distance_to(targets[score]) <= 24.0:
            collected.emit()
    queue_redraw()

func _on_collected():
    score += 1
    $Status.text = "%d / 3" % score
    if score == targets.size():
        running = false
        $RoundTimer.stop()
        $Status.text = "3 / 3 — complete; R restarts"

func _on_timeout():
    running = false
    $Status.text = "%d / 3 — time ended; R restarts" % score

func _draw():
    draw_circle(player, 12.0, Color(0.2, 0.7, 1.0))
    if running:
        var c: Vector2 = targets[score]
        draw_colored_polygon(PackedVector2Array([
            c + Vector2(-10, 10), c + Vector2(0, -10), c + Vector2(10, 10)
        ]), Color(1.0, 0.8, 0.2))
        draw_rect(Rect2(c + Vector2(-6, 3), Vector2(4, 3)), Color(0.1, 0.12, 0.14))
