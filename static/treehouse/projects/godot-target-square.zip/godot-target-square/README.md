# Target Square — Godot 4.7.2

Open project.godot in matching standard/GDScript editor, Compatibility renderer. Main has direct Status/Restart/RoundTimer children; R restarts, arrows move, three targets win,20seconds times out. See game.gd for full source. Copy exactly one variant game.gd into project root if desired; baseline remains in this archive. Seeded variant changes targets[0] only; seed 3/4 produce(80,90)/(180,180).

Actual 4.7.2.stable.official.ed 1daf0bf headless scene/input/state/timer tests passed for baseline and variants. No visual/export qualification: matching templates not installed. Install matching templates in your own supported environment and test an actual exported executable before claiming practical export success. License: original source AGPL-3.0-only.
