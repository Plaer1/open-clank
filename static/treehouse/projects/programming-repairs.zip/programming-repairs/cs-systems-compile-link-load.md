# Source to running process

- Preprocessing expands source directives; compilation lowers source through representations to machine code; an assembler makes an object file.
- A linker combines objects/libraries and resolves references into an executable or library. The OS loader maps the executable and required libraries into a process.
- `bump(x){return x+1;}` may become a few instructions. Optimization can inline or remove calls without preserving source shape.

**Try:** Label source, preprocessed text, assembly, object, executable, process. Explain why an unresolved external name can fail at linking after compilation succeeded.

## Check your reasoning
Give each stage's artifact and distinguish machine-code generation from resolving cross-object names.
## If yours differs
An object file need not be a runnable program.
## Compile an owned toy
On macOS arm64 with Apple Clang 21.0.0 and Xcode command-line tools, save toy.c in a fresh directory:

```c
int bump(int x) { return x + 1; }
int main(void) { return bump(2) == 3 ? 0 : 1; }
```

Run `clang -E toy.c -o toy.i`, `clang -S -O0 -g toy.c -o toy.s`, `clang -c -O0 -g toy.c -o toy.o`, `clang toy.o -o toy`, then `./toy`. A successful toy run exits0 without printing. Inspect with `file toy.o toy`, `nm toy.o`, and `otool -tvV toy`. Record compiler version/target and an observed symbol/instruction. Other platforms use different formats/tools. A failed command is an incomplete practical attempt; keep its diagnostic.