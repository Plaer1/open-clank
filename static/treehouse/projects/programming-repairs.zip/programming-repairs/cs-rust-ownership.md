# Moves and borrows

- Moving a non-Copy value transfers ownership. A reference borrows access; a read-only helper can borrow instead of owning.
- This complete `length_broken.rs` must leave the single String owned by main and retain the final print. String/str length counts UTF-8 bytes.

```rust
fn length(s: String) -> usize { s.len() }
fn main() {
    let label = String::from("hi");
    let n = length(label);
    println!("length={n}; label={label}");
}
```

**Try:** Identify the move and later conflicting use. Repair the helper signature and call with a shared borrow, preserving the print without cloning. Explain why cloning is a different ownership/cost choice. Optionally predict the repaired output; a prediction is not a compiler run.

## Check your reasoning
The call length(label) moves ownership into s, so the later print cannot borrow label. Use `fn length(s: &str) -> usize { s.len() }` and `length(&label)`. A consistent &String signature/borrow also works; cloning creates another owned allocation. Expected repaired output: `length=2; label=hi`. For UTF-8 "é", byte length remains2, not two perceived letters.

Complete reference repair, save separately as length_fixed.rs:

```rust
fn length(s: &str) -> usize { s.len() }
fn main() {
    let label = String::from("hi");
    let n = length(&label);
    println!("length={n}; label={label}");
}
```
## If yours differs
Adding clone can make code compile while changing cost and ownership intent.
## Go deeper
Lifetimes express relationships between reference validity, not a command to extend storage. A returned reference cannot outlive what it borrows. Ownership avoids many memory-safety errors in safe Rust; it does not guarantee correct application logic.
## Try the repair with a compiler
In a fresh owned directory with rustc1.97.1, record `rustc --version`, save the broken source as length_broken.rs, then run `rustc --edition=2024 length_broken.rs -o length-broken`. Expect rejection in the moved-value category E0382, not an exact diagnostic string. There is no new executable to run after failure. Save your repair separately as length_fixed.rs; run `rustc --edition=2024 length_fixed.rs -o length-fixed`, then `./length-fixed` only after build success. Keep source, diagnostic, actual output and status. A hand trace remains valid written work when a compiler is unavailable. No separate execution assignment is required here.