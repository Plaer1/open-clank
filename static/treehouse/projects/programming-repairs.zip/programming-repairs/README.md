# programming-repairs

Original complete broken Rust/C/parser and given-instruction inputs. Canonical C helper result 3/process 0/empty stdout; instruction interpretation is not an observed disassembler run.

Status: source-only. Extract into a new owned directory. Source/examples do not imply an external tool ran. No automatic app-origin execution; run locally only when you choose the relevant practical work. Keep source/version/evidence and report failed or unavailable tools as pending.
