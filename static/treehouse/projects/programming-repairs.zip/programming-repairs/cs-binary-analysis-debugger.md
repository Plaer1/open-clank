# Pause and inspect a call

- A debugger pauses at breakpoints and displays active frames/locals. Optimized variables may be transformed or unavailable; debugging can change timing.
- Canonical source, save-as `toy.c`:

```c
int bump(int x) { return x + 1; }
int main(void) { return bump(2) == 3 ? 0 : 1; }
```

This main checks the helper result; it does not return that result directly. The complete build/LLDB recipe is below.

**Try:** Sketch the active frames at bump entry and predict its argument/return. Separately predict main's process exit status and stdout. Explain one observation limit. Label this source trace as predicted unless you actually paused this exact build.

## Check your reasoning
At bump entry, bump is above main; x=2 and helper return is3. Main compares that result with3 and returns0: successful process exit0, empty stdout. A breakpoint/locals observation would cover only the selected run; symbols, optimization and debugger timing affect what is visible.
## If yours differs
A missing local in optimized code is not evidence that the source never had that variable.
## Build and inspect this exact toy
Save the exact toy.c above in a fresh owned directory. On macOS arm64 with Apple Clang21.0.0/Xcode command-line tools: `clang -O0 -g toy.c -o toy-debug`. Continue only after a successful fresh build; do not launch an old executable after a build error. Use `lldb ./toy-debug`, `breakpoint set --name bump`, `run`, `frame variable`, `thread backtrace`, then `thread step-over` and `continue`. Record actual frames/locals separately from the source prediction. Missing symbols, OS debug permission or unavailable tools leave inspection pending. The expected helper return3 differs from main/process exit0; stdout is empty. These LLDB steps are a tool recipe, not a claim that an inspection already occurred.