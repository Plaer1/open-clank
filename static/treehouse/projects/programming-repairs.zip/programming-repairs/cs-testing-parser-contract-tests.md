# Test a parser against its whole contract

- A parser's contract defines valid input and rejection; successful conversion alone is weaker.
- Input is a string of at most64 characters. Empty or whitespace-only input returns []. Otherwise split on commas into at most4 fields; trim each. Each field is optional ASCII minus `-` followed by at least one ASCII digit0…9, with value−9…9. No plus sign, empty field or Unicode numeral is accepted. Any contract-invalid string raises ValueError. Leading zeroes and -0 are allowed. Non-string input is outside this contract.

Supplied **broken** Python implementation:

```python
def parse_counts(text):
    if not text.strip():
        return []
    return [int(part) for part in text.split(",")]
```

**Try:** Write an expected-versus-predicted-actual test table for `"2,-1,2"`, `" 2 , 0 "`, `""`, `"  "`, `"1,,2"`, `"10"`, `"+1"`, `"1,2,3,4,5"`, `"−1"` (Unicode minus), `"２"` (fullwidth digit), and65 spaces. Identify actual contract violations; propose a repair. Label hand predictions separately from any later execution.

## Check your reasoning
Expected valid results: [2,-1,2], [2,0], [], []. All remaining cases require ValueError. The broken parser already rejects empty fields and Unicode minus, but accepts10, +1, too many fields, fullwidth digits and overlength whitespace. Those accepted inputs violate the contract.

One reference repair:

```python
def parse_counts(text):
    if len(text) > 64:
        raise ValueError("too long")
    if not text.strip():
        return []
    fields = text.split(",")
    if len(fields) > 4:
        raise ValueError("too many fields")
    result = []
    for field in fields:
        token = field.strip()
        digits = token[1:] if token.startswith("-") else token
        if not digits or any(c < "0" or c > "9" for c in digits):
            raise ValueError("bad field")
        value = int(token)
        if not -9 <= value <= 9:
            raise ValueError("out of range")
        result.append(value)
    return result
```

The length check must precede the whitespace shortcut. Accepting empty input is correct. Raising ValueError for a forbidden field is correct, not a crash bug.
## If yours differs
Calling int alone does not enforce this contract; an intentional ValueError is correct rejection.