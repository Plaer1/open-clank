int bump(int x) { return x + 1; }
int main(void) { return bump(2) == 3 ? 0 : 1; }
