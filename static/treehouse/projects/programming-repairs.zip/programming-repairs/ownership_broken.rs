fn length(s: String) -> usize { s.len() }
fn main() {
    let label = String::from("hi");
    let n = length(label);
    println!("length={n}; label={label}");
}
