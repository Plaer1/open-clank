# openclank-notes

Original scratch note/template/source inputs. Choose an actually authorized disposable location; source names are not file grants. Own-file save/reopen/read-back and native layer/course exports require real isolated qualifier evidence.

Status: source-only. Extract into a new owned directory. Source/examples do not imply an external tool ran. No automatic app-origin execution; run locally only when you choose the relevant practical work. Keep source/version/evidence and report failed or unavailable tools as pending.
