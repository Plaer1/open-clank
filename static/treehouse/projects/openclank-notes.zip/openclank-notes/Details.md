# Details
Color: blue
Next check: reopen the saved note.
