def count(rows):
    """Count rows; keep name in this comment."""
    name = len(rows)
    return name
