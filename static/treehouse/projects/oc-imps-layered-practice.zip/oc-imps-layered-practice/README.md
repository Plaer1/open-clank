# Layered native image practice

These exact portable Imps exports were produced by actual Save Project browser downloads, then loaded through the actual Load Project file input in a disposable normal-auth source app. They are unbound: provider/resource_id/revision are empty, so no missing original Files identity or recipient grant is implied.

Open before.imps.json in Image Editor with Load Project. It has two stable layers, layer-1 blue-base and layer-2 yellow-mark, on a 16x16 canvas. The base is opaque blue; the overlay is yellow only in the 4x4 origin corner. after.imps.json changes only overlay pixel(0,0) to red. Native Save/Load retained both IDs. Pixel setup used deterministic native Canvas input, not brush-gesture testing.

flattened-native.png is the actual Imps exportPNG result from the after state: red(0,0), yellow(1,1), blue(5,5). It is a single flattened image, not the editable layer stack. This is not the separately generated Pillow reference.

Source-app qualification used synthetic accounts/material only. Importing a file does not grant workspace/account permissions or complete a lesson; report your own observed save/load result when doing practical work. Original primitive source/pixels: AGPL-3.0-only; full license included.
