# Bevy Target Square

Pinned Rust 1.90.0 / Bevy 0.17.3 / edition 2024. Actual resolution produced the included Cargo.lock; cargo check --locked --jobs 2 succeeded on macOS arm64. This checks source/types/dependencies, not an actual linked game run or GPU window. Fixed target stays (200,0); player bounds x[-300,300], y[-150,150].

With pinned toolchain selected in your own environment, cargo run --locked builds/starts the game. Arrows move; R restores position and won=false. Standalone overlap-helper.rs contains the actual six-assertion boundary test: rustc --test overlap-helper.rs -o overlap-check then execute that binary. A single large x=150 to x=240 step can skip sampled collision. No Godot seed mapping is applied. Failed/missing GPU/toolchain remains pending practical work.
