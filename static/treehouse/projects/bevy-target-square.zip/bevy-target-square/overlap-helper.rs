fn overlaps_target(x: f32, y: f32) -> bool {
    (x - 200.0).abs() <= 20.0 && y.abs() <= 20.0
}
#[test]
fn inclusive_edges() {
    assert!(overlaps_target(180.0, 0.0));
    assert!(overlaps_target(220.0, 0.0));
    assert!(!overlaps_target(179.99, 0.0));
    assert!(!overlaps_target(220.01, 0.0));
    assert!(overlaps_target(200.0, 20.0));
    assert!(!overlaps_target(200.0, 20.01));
}
