# asset-handoff

Original editable SVG and exact Blender box/material/animation/import specification. Actual Inkscape export/BLEND/GLB artifacts are not present or claimed; optional practical work stays pending until tools produce/import them.

Status: source-only. Extract into a new owned directory. Source/examples do not imply an external tool ran. No automatic app-origin execution; run locally only when you choose the relevant practical work. Keep source/version/evidence and report failed or unavailable tools as pending.
