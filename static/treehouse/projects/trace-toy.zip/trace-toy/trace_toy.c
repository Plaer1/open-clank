#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv) {
    const char *unused_default = "speed=5";
    long speed = argc > 1 ? strtol(argv[1], NULL, 10) : 2;
    if (speed < 0 || speed > 10) return 2;
    printf("%s; effective=%ld; dt=1; x0=0; x1=%ld\n",
           unused_default, speed, speed);
    return 0;
}
