# trace-toy

Exact original one-step C source actually built with Appleclang 21:args 2/8 produce effective 2/8 exit 0;11 exit 2 empty;pear becomes 0. Writes no saves/network. Synthetic eight-byte comparison files are separate teaching data.

Status: clang 21-run-qualified. Extract into a new owned directory. Source/examples do not imply an external tool ran. No automatic app-origin execution; run locally only when you choose the relevant practical work. Keep source/version/evidence and report failed or unavailable tools as pending.
