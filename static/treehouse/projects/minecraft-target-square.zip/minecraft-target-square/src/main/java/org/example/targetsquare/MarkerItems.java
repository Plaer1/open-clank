package org.example.targetsquare;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

public final class MarkerItems {
    private static final ResourceKey<Item> MARKER_KEY = ResourceKey.create(
        Registries.ITEM,
        Identifier.fromNamespaceAndPath(TargetSquare.MOD_ID, "marker")
    );
    public static final Item MARKER = Registry.register(
        BuiltInRegistries.ITEM,
        MARKER_KEY,
        new Item(new Item.Properties().setId(MARKER_KEY))
    );

    private MarkerItems() { }
    public static void initialize() { }
}
