package org.example.targetsquare;

import net.fabricmc.api.ModInitializer;

public final class TargetSquare implements ModInitializer {
    public static final String MOD_ID = "target_square";

    @Override
    public void onInitialize() {
        MarkerItems.initialize();
    }
}
