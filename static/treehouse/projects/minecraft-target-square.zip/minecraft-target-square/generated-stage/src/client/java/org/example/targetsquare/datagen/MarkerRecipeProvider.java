package org.example.targetsquare.datagen;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.world.item.Items;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import org.example.targetsquare.MarkerItems;

public final class MarkerRecipeProvider extends FabricRecipeProvider {
    public MarkerRecipeProvider(FabricDataOutput output,
            CompletableFuture<HolderLookup.Provider> registries) {
        super(output, registries);
    }

    @Override
    protected RecipeProvider createRecipeProvider(HolderLookup.Provider lookup,
            RecipeOutput sink) {
        return new RecipeProvider(lookup, sink) {
            @Override
            public void buildRecipes() {
                shapeless(RecipeCategory.MISC, MarkerItems.MARKER)
                    .requires(Items.STICK)
                    .unlockedBy("has_stick", has(Items.STICK))
                    .save(output);
            }
        };
    }

    @Override
    public String getName() {
        return "Target Square marker recipe";
    }
}
